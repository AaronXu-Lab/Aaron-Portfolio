# @aaronxu-lab/aaron-ui

Aaron design system — React component library and design tokens.

Aaron 设计系统 —— React 组件库与设计 token。

## Other platforms / 其他平台

- [AaronUI-SwiftUI](https://github.com/AaronXu-Lab/AaronUI-SwiftUI)：iOS 与 macOS 组件库。
- [AaronUI-Android](https://github.com/AaronXu-Lab/AaronUI-Android)：Jetpack Compose 组件库。

> **Status: 0.x, no stability promise.** Props are the public API, and they will
> break on minor versions while the design language is still moving. Pin an exact
> version if you depend on this today.
>
> **状态：0.x，不承诺稳定。** props 即公开 API，在设计语言仍在演进期间会随 minor
> 版本发生破坏性变更。当前如需依赖，请锁定精确版本。

Documentation: [current guides](docs/README.md) and [historical records](docs/archive/README.md). The [manually started local MCP](mcp/README.md) serves design agents with intent-based discovery, design choices and composition guidance, and direct Gallery visual references across Components, Docs, Styles and Scenarios. See the MCP 4.1 contract; Props and source are opt-in, and source Example access remains limited to reviewed Dialog examples.

文档入口：[当前指南](docs/README.md)与[历史记录](docs/archive/README.md)。

## Install / 安装

```bash
npm install @aaronxu-lab/aaron-ui
```

`react`, `react-dom`, `@base-ui/react`, `@phosphor-icons/react`, `@shadcn/react`,
`shiki` and `sonner` are peer dependencies — install them alongside.

`react`、`react-dom`、`@base-ui/react`、`@phosphor-icons/react`、`@shadcn/react`、
`shiki` 和 `sonner` 是 peer 依赖，需要一并安装。

## Usage / 使用

Import the stylesheet once at your app root, then use components anywhere.

在应用根部引入一次样式表，之后即可在任意位置使用组件。

```tsx
import '@aaronxu-lab/aaron-ui/styles.css'
import { Button, UiProvider } from '@aaronxu-lab/aaron-ui'

export function App() {
  return (
    <UiProvider>
      <Button variant="fill">Continue</Button>
    </UiProvider>
  )
}
```

Themes switch through `data-theme` on the root element:

主题通过根元素上的 `data-theme` 切换：

```ts
document.documentElement.dataset.theme = 'dark' // or 'light'
```

## Color theme configuration / 颜色主题配置

Pass a partial `ColorThemeConfig` to `<UiProvider colorTheme={config}>`. Missing colors retain their default definitions and alias relationships; light and dark can be configured separately. See [the integration guide, token reference graph and primitive ramp organization](docs/theme-maintenance.md).

通过 `<UiProvider colorTheme={config}>` 加载部分颜色配置，未填写项保留默认定义及引用关系，浅／深模式分别配置。详见[接入指导、颜色引用关系与 Primitives 组织方式](docs/theme-maintenance.md)。

## Lightbox document themes / Lightbox 文档主题

Document previews follow the root theme. See [theme overrides, spreadsheet contrast and deployment requirements](docs/modals-and-previews.md).

文档预览默认跟随根主题；详见[主题覆盖、表格对比度及部署要求](docs/modals-and-previews.md)。

## Composer references / Composer 引用

Composer and ComposerInline support optional structured documents, atomic resource references, mapped selection bookmarks and application-owned @ suggestions. See [the public contract and integration examples](docs/composer-integration.md).

Composer 与 ComposerInline 支持可选结构化文档、原子资源引用、映射选区书签与应用自管的 @ 建议。详见[公开契约与接入示例](docs/composer-integration.md)。

Message Query and Message Answer can display the sent Composer document as a read-only snapshot, including inline resource references. Existing plain text, Markdown renderers and custom blocks remain compatible. See [ADM integration and visual regression evidence](docs/message-integration.md).

Message Query 与 Message Answer 可只读展示发送时的 Composer 文档快照及行内引用，保留纯文本、Markdown 渲染器与自定义块兼容。详见 [ADM 接入与视觉回归证据](docs/message-integration.md)。


## CodeBlock / 代码块

```tsx
import { CodeBlock } from '@aaronxu-lab/aaron-ui'

<CodeBlock
  code={'const message = "Hello"\n'}
  language="typescript"
  aria-label="Code"
  highlightLabel="Syntax highlighting"
  copyLabel="Copy code"
  copiedLabel="Copied"
  copyErrorLabel="Could not copy. Select the code and copy it manually."
/>
```

Copy always uses the original `code`. The viewer starts in `highlighted` mode;
use `defaultValue="plain"` to start without loading the highlighter, or control
the mode with `value` and `onValueChange`. The floating icon button toggles
highlighting without occupying a separate row. Buttons overlay the text without
reducing its display width. All accessible names and feedback
strings are required consumer props; the component has no built-in copy or
language switcher. `language` only selects the syntax grammar, and is not displayed.
The source remains visible while highlighting loads. Unsupported languages,
empty content and loading failures hide the toggle and show plain text without
a fallback message. Both axes scroll inside the code area. Native `style` sizing
can constrain the viewer's height.

`font` defaults to `"body"`, sharing InputArea's body typography. Set `font="mono"`
to use the system monospace stack for code. Font size, line height and padding
stay the same in both modes; tooltips and controls keep their own typography.

Like InputArea, `draggable` defaults to `"none"`. Set it to `"horizontal"`,
`"vertical"` or `"both"` to enable the bottom-right resize handle. Horizontal
resizing stays within the container; native `style` min/max dimensions can add
constraints. Resizing keeps the controls pinned and the code scrollable.

`wrap` defaults to `true`, wrapping long lines, including unbroken strings, in both
plain and highlighted modes. Set `wrap={false}` to use horizontal scrolling. Wrapping
preserves source whitespace and line breaks, and copy still returns the original code.

`actionsVisibility` defaults to `"hover"`: the floating buttons appear when the
code block is hovered or contains focus. Set `"always"` to keep them visible, or
`"never"` to omit them entirely. On devices without hover, `"hover"` keeps the
buttons visible for touch access; `"never"` remains hidden.

复制始终使用原始 `code`。默认采用 `highlighted` 模式；设置 `defaultValue="plain"`
可从普通模式开始且不加载高亮引擎，也可通过 `value` 和 `onValueChange` 控制模式。
右上角悬浮图标按钮切换高亮，直接浮在文本上，不占用独立一行或文本显示宽度。所有可访问名称与反馈文案均为必填的
外层参数；组件不内置文案或语言切换器。`language` 只选择语法，不显示为界面提示。
加载期间显示原文；未知语言、空内容或加载失败时隐藏高亮按钮，静默展示普通文本。
超长内容在代码区内横向、纵向滚动，也可通过原生 `style` 约束组件高度。

`font` 默认为 `"body"`，与 InputArea 共用正文排版。设置 `font="mono"` 可切换为
系统等宽代码字体。两种模式的字号、行高和内边距一致，提示与按钮保留自身排版。

与 InputArea 一致，`draggable` 默认为 `"none"`；设置 `"horizontal"`、`"vertical"`
或 `"both"` 即可从右下角拖动调整尺寸。横向调整限制在容器内，也可通过原生 `style`
的最小／最大尺寸添加约束。调整后按钮保持悬浮，代码仍可滚动。

`wrap` 默认为 `true`，普通和高亮模式下的长行自动换行，包括没有空格的连续字符串。
设置 `wrap={false}` 可改为横向滚动。换行保留源码空白及换行符，复制结果仍为原始代码。

`actionsVisibility` 默认为 `"hover"`，悬停代码块或内部获得焦点时显示悬浮按钮；
设置 `"always"` 可让按钮常驻，`"never"` 则完全不渲染操作按钮。不支持悬停的设备上，
`"hover"` 保持显示以便触摸操作，`"never"` 仍不显示。

Languages: JavaScript (`js`), TypeScript (`ts`), JSX, TSX, JSON, JSONC, HTML,
CSS, Bash (`sh` / `shell`), Python (`py`), SQL, YAML (`yml`) and Markdown (`md`).
Omitting `language` uses plain text (`text`). Shiki's JavaScript engine and
individual grammars load on demand; the package keeps these imports external
so consumer bundlers can split them into lazy chunks. No WebAssembly is needed.

支持 JavaScript、TypeScript、JSX、TSX、JSON、JSONC、HTML、CSS、Bash、Python、SQL、
YAML、Markdown 及以上简写；省略 `language` 时按纯文本（`text`）处理。Shiki 的
JavaScript 引擎和语法按需加载；包内保留外部导入，由消费方构建工具拆分懒加载文件，
无需 WebAssembly。

## Development / 开发

```bash
npm install
npm run dev             # Astro Gallery on :7680
npm run typecheck
npm run typecheck:gallery # Astro pages and React islands
npm run build           # component library (Vite)
npm run build:gallery   # Astro static site for /aaronui/
npm run preview:gallery
npm run check:boundary  # fails if src/ reaches back into an app
```

## License / 许可

MIT. See [`THIRD_PARTY_LICENSES.txt`](./THIRD_PARTY_LICENSES.txt) for third-party attributions.

MIT。第三方归属见 [`THIRD_PARTY_LICENSES.txt`](./THIRD_PARTY_LICENSES.txt)。

### Dialog actions

Fixed modals support an optional application-wide `--ui-viewport-min-width` CSS property. See [modal viewport configuration](docs/modals-and-previews.md) for root/portal inheritance, preserved safety insets and the default behavior.

固定模态支持可选的应用级 CSS 属性 `--ui-viewport-min-width`。根节点／Portal 继承、安全边距与默认行为详见[模态视口配置](docs/modals-and-previews.md)。

Use structured `primaryAction` / `secondaryAction` configurations for standard Dialog footers. See [the migration guide](docs/modals-and-previews.md) for the `actions` composition enum, `customActions`, and keyboard/form behavior.
